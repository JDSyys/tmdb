package edu.whu.tmdb.query.operations.impl;/*
 * className:OrderBy
 * Package:edu.whu.tmdb.Transaction.Transactions.impl
 * Description:
 * @Author: xyl
 * @Create:2023/8/6 - 20:39
 * @Version:v1
 */

public class OrderBy {
}
