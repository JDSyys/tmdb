package edu.whu.tmdb.query.operations.utils;

public class Constants {
    public static final String TORCH_RES_BASE_DIR="data/res";
}

