package au.edu.rmit.bdm.clustering.Streaming;

public class CarIdEdge {
    public int carId;
    public int edge;

    public CarIdEdge(int carId, int edge){
        this.carId = carId;
        this.edge = edge;
    }
}
