package au.edu.rmit.bdm.clustering.trajectory.traclus;

/*
 * we extend paper "Trajectory clustering: a partition-and-group framework" in this class.
 * 1. frequency
 * 2. parameter to construct the heat map
 */
public class Baseline {

}
