package au.edu.rmit.bdm.Torch.base.tmdb;/*
 * className:TmdbAdaptor
 * Package:au.edu.rmit.bdm.Torch.base.tmdb
 * Description:
 * @Author: xyl
 * @Create:2023/7/23 - 15:27
 * @Version:v1
 */

public class TmdbAdaptor {

}
