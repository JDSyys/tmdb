package au.edu.rmit.bdm.Torch.base;

public interface Index {
    boolean build(String path);
}
