package au.edu.rmit.bdm.Torch.queryEngine.model;

public interface Geometry {
}
